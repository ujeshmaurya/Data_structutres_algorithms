#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *link;
};

int main()
{
	int n=1,i,m,k;
	struct node *start,*start1,*ptr,*temp,*temp2,*temp3;
	start=NULL;
	printf("Enter the no. of elements to be created at first\n");
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		if(i==0)
		{
			ptr=(struct node*)malloc(sizeof(struct node));
			printf("Enter the data for 1st node: \n");
			scanf("%d",&ptr->data);
			ptr->link=NULL;
			start=ptr;
			printf("1st node constructed\n");
		}
		else if(i>0)
		{
			ptr=(struct node*)malloc(sizeof(struct node));
			printf("Enter the data for %d node: \n",i+1);
			scanf("%d",&ptr->data);
			ptr->link=NULL;
			if(i==1)
				start->link=ptr;
			else
				temp->link=ptr;
			temp=ptr;
		}
		
	}
	printf("Reversed linked list: \n");
	ptr=start;
	while(ptr->link!=NULL)
		ptr=ptr->link;
	start1=ptr;
	temp=ptr;
	lab2:
	ptr=start;
	while(ptr->link!=temp)
	{
		ptr=ptr->link;
		
	}
	temp->link=ptr;
		temp=ptr;
	if(ptr!=start)
		goto lab2;
	start->link=NULL;
	ptr=start1;
	while(ptr!=NULL)
	{
		printf("%d ",ptr->data);
		ptr=ptr->link;
	}
	
	
}
