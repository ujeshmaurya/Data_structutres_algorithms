#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *link;
};

int main()
{
	int n=1,i,m,k,count=1;
	struct node *start,*ptr,*temp,*temp2,*temp3;
	start=NULL;
	printf("Enter the no. of elements to be created at first\n");
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		if(i==0)
		{
			ptr=(struct node*)malloc(sizeof(struct node));
			printf("Enter the data for 1st node: \n");
			scanf("%d",&ptr->data);
			ptr->link=NULL;
			start=ptr;
			temp=start;
			printf("1st node constructed\n");
		}
		else if(i>0)
		{
			ptr=(struct node*)malloc(sizeof(struct node));
			printf("Enter the data for %d node: \n",i+1);
			scanf("%d",&ptr->data);
			ptr->link=NULL;
			temp->link=ptr;
			temp=ptr;
		}
		
	}
	ptr=start;
	if(m%2==1)
	{
		ptr=start;
		for(i=2;i<(m+1)/2;i++)
		{
			ptr=ptr->link;
		}
		temp=ptr->link;
		temp2=temp->link;
		ptr->link=temp2;
		temp->link=NULL;
	}
	else
	{
		ptr=start;
		for(i=1;i<m/2;i++)
		{
			ptr=ptr->link;
		}
		temp=ptr->link;
		temp2=temp->link;
		ptr->link=temp2;
		temp->link=NULL;
	}
	printf("After deleting the Middle elements,The linked list becomes: \n");
	ptr=start;
	while(ptr!=NULL)
	{
		printf("%d ",ptr->data);
		ptr=ptr->link;
	}
	printf("\n");
	
	
}
